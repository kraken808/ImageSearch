//
//  NetworkError.swift
//  ChocofoodProject
//
//  Created by Murat Merekov on 08.01.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import Foundation

//public enum APIError: Codable{
//    var message: String
//    var error: String
//}

struct StatusResponse: Decodable{
    var message: String
}
